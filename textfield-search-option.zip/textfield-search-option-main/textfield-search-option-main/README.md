# textfield-search-option
Custom using java swing with animation

![ezgif com-gif-maker](https://user-images.githubusercontent.com/58245926/193450660-0ae24edb-37d7-4a7a-92bf-c58c90393b55.gif)
