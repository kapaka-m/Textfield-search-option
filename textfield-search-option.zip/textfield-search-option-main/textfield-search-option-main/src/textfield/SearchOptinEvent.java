package textfield;

public interface SearchOptinEvent {

    public void optionSelected(SearchOption option, int index);
}
